package com.example.varsity_4_u

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
