import 'package:flutter/material.dart';
import 'package:varsity_4_u/pages/profile.dart';



class HomePage extends StatelessWidget {
   HomePage({super.key});
  final List<Course> courses = [
    Course(
      title: 'Economic and Management Science',

      description: '"review": "the general admission requirements, the candidate must be in possession of an NSC with endorsement for admission to a bachelor’s degree.  A candidate selecting Mathematics as a major subject must have passed either Mathematics with a minimum mark of 50%, or Mathematical Literacy with a minimum mark of 70%.  A minimum mark of 50% in Accounting is required, irrespective of whether or not the candidate continues with Accounting after year one.",',
      imageUrl: 'https://tinyurl.com/576b9ru2',
    ),
    Course(
      title: 'Information Technology',
      description: 'the general admission requirements, a minimum mark of 60% on Standard Grade or 40% on Higher Grade in Mathematics or Computer Studies is required..',
      imageUrl: 'https://shorturl.at/LSW29',)
     
    // Add more courses as needed
  ];



  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
           actions: const [
            Icon(Icons.logout)
           ],
          title: const Text('Varsity 4 U'),
          backgroundColor: Colors.teal,
        ),
        
        drawer: const AppDrawer(),
       body: ListView.builder(
          itemCount: courses.length,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CourseDetailPage(course: courses[index]),
                  ),
                );
              },
              child: CourseCard(course: courses[index]),
            );
          },
        ),
      ),
    );
  }
}

class Course {
  final String title;
  final String description;
  final String imageUrl;

  Course({
    required this.title,
    required this.description,
    required this.imageUrl,
  });
}

class CourseCard extends StatelessWidget {
  final Course course;

  const CourseCard({super.key, required this.course});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Image.network(
            course.imageUrl,
            height: 150.0,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  course.title,
                  style: const TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  course.description,
                  style: const TextStyle(fontSize: 16.0),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CourseDetailPage extends StatelessWidget {
  final Course course;

  const CourseDetailPage({super.key, required this.course});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(course.title),
      ),
      body: Card(
        margin: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.network(
              course.imageUrl,
              height: 200.0,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
               
                  Text(
                    course.title,
                    style: const TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 9,),
                  Text(
                    course.description,
                    style: const TextStyle(fontSize: 18.0),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

    
  

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: Center(
          child: ListView(
          
              children: 
               [
          const DrawerHeader(
        
              child: Icon(Icons.person, size: 130, color: Colors.grey,)
            
            
            
          ),
          const SizedBox(height: 20,),
           ListTile(
          title: const Text('  Profile', style: TextStyle(fontSize: 25),
          ),
          trailing: const Icon(Icons.person, size: 50, color: Colors.black,),
          onTap: (){
            Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) =>  ProfilePage(),
                      ));
          },
          ),
          
        
           
              ],
            ),
        ));
  }
}
