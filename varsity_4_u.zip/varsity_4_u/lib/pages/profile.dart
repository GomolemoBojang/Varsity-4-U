import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  // Dummy user data
  final User user = User(
    name: 'John Doe',
    email: 'john.doe@example.com',
    profilePictureUrl: 'assets/images/profile_placeholder.png',
  );

  ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 80.0,
              backgroundImage: NetworkImage(user.profilePictureUrl),
            ),
            const SizedBox(height: 16.0),
            Text(
              user.name,
              style: const TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8.0),
            Text(
              user.email,
              style: const TextStyle(fontSize: 16.0),
            ),
            const SizedBox(height: 24.0),
            ElevatedButton(
              onPressed: () {
              },
              child: const Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}

class User {
  final String name;
  final String email;
  final String profilePictureUrl;

  User({
    required this.name,
    required this.email,
    required this.profilePictureUrl,
  });
}
