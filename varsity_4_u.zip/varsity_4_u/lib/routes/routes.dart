import 'package:flutter/material.dart';
import 'package:varsity_4_u/pages/home_page.dart';
import 'package:varsity_4_u/pages/profile.dart';





class RouteManager {

  static const String homePage = '/';
   static const String profilePage = '/profilePage';




  static Route<dynamic>? onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      
      
      case homePage:
        return MaterialPageRoute(
          builder: (context) =>  HomePage(),
        );
       
   
         case profilePage:
        return MaterialPageRoute(
          builder: (context) =>  ProfilePage(),
        );




      default:
        throw Exception('Check pages. The one you used does not exist!');
    }
  }
}
