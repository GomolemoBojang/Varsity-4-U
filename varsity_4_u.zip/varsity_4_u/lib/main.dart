import 'package:flutter/material.dart';
import 'package:varsity_4_u/pages/home_page.dart';


void main() {
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    //builds a tree of providers from multiple classes
    return 
       MaterialApp(
        debugShowCheckedModeBanner: false,
       theme: ThemeData(
        // Define the primary color of your app.
        primaryColor: Colors.teal,),
        home:  HomePage(),
        );
 
      
  
  }
}
