// ignore_for_file: use_build_context_synchronously

import 'package:provider/provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:backendless_sdk/backendless_sdk.dart';
import 'package:varsity_4_u/routes/routes.dart';
import 'package:varsity_4_u/services/subjects_service.dart';
import 'package:varsity_4_u/services/user_service.dart';

class InitApp {
  static const String apiKeyAndroid = 'B139B99C-E8AD-4CB0-9048-1E51F7C57AA1';
  static const String apiKeyiOS = 'C7158444-0729-45B0-9A1F-588BBAFD4DB6';
  static const String appID = 'D897F48C-6051-FCF3-FFD6-60C3558E0300';

  static Future<void> initializeApp(BuildContext context) async {
    await Backendless.initApp(
      applicationId: appID,
      iosApiKey: apiKeyiOS,
      androidApiKey: apiKeyAndroid,
    );

    String result = await context.read<UserManagement>().checkIfUserLoggedIn();
    if (result == 'OK') {
      context
          .read<SubjectService>()
          .getSubjects(context.read<UserManagement>().currentUser!.email);
      Navigator.popAndPushNamed(context, RouteManager.subjectsReflection);
    } else {
      Navigator.popAndPushNamed(context, RouteManager.loginPage);
    }
  }
}
