import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:varsity_4_u/models/subjects.dart';

class SubjectsCard extends StatelessWidget {
  const SubjectsCard({
    Key? key,
    required this.deleteAction,
    required this.subjects,
  }) : super(key: key);

  final Subjects subjects;
  final Function() deleteAction;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Color.fromARGB(255, 82, 130, 220),
      child: Slidable(
        // Configuring the Slidable widget
        startActionPane: ActionPane(
          motion: const DrawerMotion(),
          extentRatio: 0.25,
          children: [
            // Defining a single SlidableAction for delete functionality
            SlidableAction(
              label: 'Delete',
              icon: Icons.delete,
              backgroundColor: Color.fromARGB(255, 255, 2, 2),
              onPressed: (context) {
                deleteAction();
              },
            )
          ],
        ),
        child: ListTile(
          leading: const Icon(
            Icons.menu_book_rounded,
            color: Colors.white,
            size: 40,
          ),
          title: Text(
            subjects.subjectDesc,
            style: const TextStyle(
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
