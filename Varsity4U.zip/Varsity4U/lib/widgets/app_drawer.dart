import 'package:flutter/material.dart';
import 'package:varsity_4_u/pages/aps_calculator.dart';
import 'package:varsity_4_u/pages/resources.dart';
import 'package:varsity_4_u/pages/subjects_view.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: Center(
      child: ListView(
        children: [
          const DrawerHeader(
              child: Icon(
                        Icons.person,
                        size: 130,
                        color: Colors.grey,
                )),
          
          const SizedBox(
            height: 20,
          ),
       
          ListTile(
            leading: const Icon(
              Icons.view_agenda,
              size: 30,
              color: Colors.blue,),
            title: const Text(
              '  APS',
              style: TextStyle(fontSize: 25),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.blue,),
            
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) =>   APSCalculator()
              ));
            },
          ),
          ListTile(
            leading: const Icon(Icons.subject, size: 30, color: Colors.blue,),
            title: const Text(
              '  Subjects',
              style: TextStyle(fontSize: 25),
            ),
             trailing: const Icon(Icons.arrow_forward_ios, color: Colors.blue,),

            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) =>  const SubjectsView()
              ));
            },
          ),
          ListTile(
            leading: const Icon(Icons.book, size: 30, color: Colors.blue,),
            title: const Text(
              '  Resources',
              style: TextStyle(fontSize: 25),
            ),
          trailing: const Icon(Icons.arrow_forward_ios, color: Colors.blue,),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) =>  Resources()
              ));
            },
          ),
         const SizedBox(height: 145,),
          ListTile(
            title: const Text(
              '  Exit',
              style: TextStyle(fontSize: 25),
            ),
            trailing: const Icon(
              Icons.exit_to_app,
              size: 45,
              color: Colors.red,
            ),
            onTap: () {
               Navigator.pop(context);
            },
          ),
        
    ]  ),
    ));
  }
}
