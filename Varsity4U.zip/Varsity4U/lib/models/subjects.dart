// This function converts a List of Subjects objects to a Map.
// ignore_for_file: avoid_renaming_method_parameters

Map<dynamic, dynamic> convertSubjectListToMap(List<Subjects> subjects) {
  Map<dynamic, dynamic> map = {};

  // Iterate over each Subjects object in the list
  for (var i = 0; i < subjects.length; i++) {
    // Add the index as a string key and the serialized JSON representation of the Subjects object as the value to the map
    map.addAll({'$i': subjects[i].toJson()});
  }

  // Return the resulting map
  return map;
}

// This function converts a Map to a List of Subjects objects.
List<Subjects> convertMapToSubjectList(Map<dynamic, dynamic> map) {
  List<Subjects> subjects = [];

  // Iterate over each entry in the map
  for (var i = 0; i < map.length; i++) {
    // Retrieve the serialized JSON representation of the Subjects object using the index as a string key
    // and convert it back to a Subjects object using the fromJson constructor
    subjects.add(Subjects.fromJson(map['$i']));
  }

  // Return the resulting list of Subjects objects
  return subjects;
}

// The Subjects class represents a subjects with a description and reflections.
class Subjects {
  final String subjectDesc;
  final String reflections;

  // Constructor for the Subjects class
  Subjects({
    required this.subjectDesc,
    required this.reflections,
  });

  // This method serializes the Subjects object to a JSON-compatible Map.
  Map<String, Object?> toJson() => {
        'subjectDesc': subjectDesc,
        'reflections': reflections,
      };

  // This method deserializes a JSON-compatible Map back into a Subjects object.
  static Subjects fromJson(Map<dynamic, dynamic>? json) => Subjects(
        subjectDesc: json!['subjectDesc'] as String,
        reflections: json['reflections'] as String,
      );

  // Override the equality operator to compare Subjects objects.
  // Two Subjects objects are considered equal if their subjectDesc values are the same (case-insensitive comparison).
  @override
  bool operator ==(covariant Subjects subjects) {
    return (subjectDesc.toUpperCase().compareTo(subjects.subjectDesc.toUpperCase()) ==
        0);
  }

  // Override the hashCode getter to ensure consistent hashing based on the subjectDesc value.
  @override
  int get hashCode {
    return subjectDesc.hashCode;
  }
}
