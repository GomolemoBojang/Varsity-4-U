// ignore_for_file: file_names

// The SubjectsEntry class represents an entry containing subjects, associated with a username and metadata.
class SubjectEntry {
  Map<dynamic, dynamic> subjects; // A map representing the subjects
  String username; // The username associated with the subjects entry
  String? objectId; // An optional identifier for the object
  DateTime? created; // An optional DateTime indicating the creation time
  DateTime? updated; // An optional DateTime indicating the last update time

  // Constructor for the SubjectsEntry class
  SubjectEntry ({
    required this.subjects,
    required this.username,
    this.objectId,
    this.created,
    this.updated,
  });

  // This method serializes the SubjectsEntry object to a JSON-compatible Map.
  Map<String, Object?> toJson() => {
        'username': username,
        'Subjects': subjects,
        'created': created,
        'updated': updated,
        'objectId': objectId,
      };

  // This method deserializes a JSON-compatible Map back into a SubjectsEntry object.
  static SubjectEntry fromJson(Map<dynamic, dynamic>? json) => SubjectEntry(
        username: json!['username'] as String,
        subjects: json['subjects'] as Map<dynamic, dynamic>,
        objectId: json['objectId'] as String?,
        created: json['created'] as DateTime?,
      );
}
