// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:varsity_4_u/models/subjects.dart';

import 'package:varsity_4_u/services/subjects_service.dart';
import 'package:varsity_4_u/services/user_service.dart';
import 'package:varsity_4_u/widgets/dialogs.dart';

// Refreshes the subjects in the UI by fetching them from the database
void refreshSubjectsInUI(BuildContext context) async {
  String result = await context.read<SubjectService>().getSubjects(
        context.read<UserManagement>().currentUser!.email,
      );

  if (result != 'OK') {
    showSnackBar(context, result);
  } else {
    showToast('Data successfully retrieved from the database.');
  }
}

// Saves all subjects in the UI to the database
void saveAllSubjectsInUI(BuildContext context) async {
  String result = await context
      .read<SubjectService>()
      .saveSubjectEntry(context.read<UserManagement>().currentUser!.email, true);

  if (result != 'OK') {
    showSnackBar(context, result);
  } else {
    showToast('Data successfully saved online');
  }
}

// Creates a new subject in the UI
void createNewSubjectInUI(
  BuildContext context, {
  required TextEditingController subjectdesccontroller,
  required TextEditingController reflectionscontroller,
}) async {
  if (subjectdesccontroller.text.isEmpty || reflectionscontroller.text.isEmpty) {
    showToast('Please enter a subject first, then save!');
  } else {
    Subjects subject = Subjects(
      subjectDesc: subjectdesccontroller.text.trim(),
      reflections: reflectionscontroller.text.trim(),
    );

    // Check if the subject already exists in the subjects list
    if (context.read<SubjectService>().subjects.contains(subject)) {
      showDialogBox(context, 'Duplicate value. Please try again.');
    } else {
      subjectdesccontroller.text = '';
      reflectionscontroller.text = '';

      // Create the subject and add it to the subject list
      context.read<SubjectService>().createSubject(subject);
      Navigator.pop(context); // Close the current screen/dialog
    }
  }
}
