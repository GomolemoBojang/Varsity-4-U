import 'package:backendless_sdk/backendless_sdk.dart';
import 'package:flutter/material.dart';
import 'package:varsity_4_u/models/subject_entry.dart';
import 'package:varsity_4_u/models/subjects.dart';

class SubjectService with ChangeNotifier {
  SubjectEntry?
      _subjectsEntry; // Holds the SubjectsEntry object retrieved from the backend
  late Subjects currentSubjects; // Holds the currently selected Subject object

  List<Subjects> _subjects = []; // Holds the list of Subjects objects
  List<Subjects> get subjects => _subjects; // Getter for the subject list

  void emptySubjects() {
    _subjects = []; // Clears the subject list
    notifyListeners();
  }

  bool _busyRetrieving =
      false; // Flag to indicate if subjects retrieval is in progress
  bool _busySaving = false; // Flag to indicate if subejcts saving is in progress

  bool get busyRetrieving => _busyRetrieving; // Getter for busyRetrieving flag
  bool get busySaving => _busySaving;

  Future<String> getSubjects(
    String username,
  ) async {
    String result = 'OK'; // Holds the result of the operation

    // Create a DataQueryBuilder to query the SubjectsEntry table for a specific username
    DataQueryBuilder queryBuilder = DataQueryBuilder()
      ..whereClause = "username = '$username'";

    _busyRetrieving = false; // Set the busyRetrieving flag to true
    notifyListeners();

    // Retrieve the SubjectsEntry object from the backend using Backendless SDK
    List<Map<dynamic, dynamic>?>? map = await Backendless.data
        .of('SubjectEntry')
        .find(queryBuilder)
        .onError((error, stackTrace) {
      result = error.toString();
      return null; // Set the result to the error message if an error occurs
    });

    // Check the result of the operation
    if (result != 'OK') {
      _busyRetrieving = false; // Set the busyRetrieving flag to false
      notifyListeners();
      return result;
    }

    if (map != null) {
      if (map.isNotEmpty) {
        _subjectsEntry = SubjectEntry.fromJson(
            map.first); // Parse the SubjectsEntry object from the retrieved map
        _subjects = convertMapToSubjectList(_subjectsEntry!
            .subjects); // Convert the subject map to a list of Subjects objects
        notifyListeners();
      } else {
        emptySubjects(); // If no SubjectsEntry object is found, empty the subjects list
      }
    } else {
      result =
          'NOT OK'; // Set the result to an error message if the retrieved map is null
    }
    _busyRetrieving = false; // Set the busyRetrieving flag to false
    notifyListeners();
    return result;
  }

  Future<String> saveSubjectEntry(String username, bool inUI) async {
    String result = 'OK'; // Holds the result of the operation

    if (_subjectsEntry == null) {
      _subjectsEntry =
          SubjectEntry(subjects: convertSubjectListToMap(_subjects), username: username);
    } else {
      _subjectsEntry!.subjects = convertSubjectListToMap(_subjects);
    }

    if (inUI) {
      _busySaving = true; // Set the busySaving flag to true
      notifyListeners();
    }

    // Save the SubjectEntry object to the backend using Backendless SDK
    await Backendless.data
        .of('SubjectEntry')
        .save(_subjectsEntry!.toJson())
        .onError((error, stackTrace) {
      result = error.toString();
      return null; // Set the result to the error message if an error occurs
    });

    if (inUI) {
      _busySaving = false; // Set the busySaving flag to false
      notifyListeners();
    }

    return result;
  }

  void deleteSubject(Subjects subject) {
    _subjects.remove(subject); // Remove the specified subject from the subjects list
    notifyListeners();
  }

  void createSubject(Subjects subject) {
    _subjects.insert(0,
        subject); // Insert the specified subject at the beginning of the subjects list
    notifyListeners();
  }
}
