
import 'package:backendless_sdk/backendless_sdk.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart' as provider;
import 'package:tuple/tuple.dart';
import 'package:varsity_4_u/pages/aps_calculator.dart';
import 'package:varsity_4_u/pages/resources.dart';
import 'package:varsity_4_u/pages/subjects_view.dart';
import 'package:varsity_4_u/services/helper_subjects.dart';
import 'package:varsity_4_u/services/helper_user.dart';
import 'package:varsity_4_u/services/subjects_service.dart';
import 'package:varsity_4_u/services/user_service.dart';
import 'package:varsity_4_u/widgets/app_progress_indicator.dart';
import 'package:varsity_4_u/widgets/subjects_card.dart';

class SubjectsReflection extends StatefulWidget {
  const SubjectsReflection({Key? key}) : super(key: key);

  @override
  State<SubjectsReflection> createState() => _SubjectsReflectionState();
}

class _SubjectsReflectionState extends State<SubjectsReflection> {
  late TextEditingController subjectDesccontroller;
  late TextEditingController reflectionscontroller;

  @override
  void initState() {
    super.initState();
    subjectDesccontroller = TextEditingController();
    reflectionscontroller = TextEditingController();
  }

  @override
  void dispose() {
    subjectDesccontroller.dispose();
    reflectionscontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Scaffold widget represents the main screen structure in Flutter.
        return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Varsity 4 U'),
        actions: [
          // Add your action buttons here
          IconButton(
         icon: const Icon(
         Icons.exit_to_app,
         color: Colors.white,
         size: 30,
           ),
         onPressed: () {
         logoutUserInUI(context);
            },
           ),
        ],
      ),
      drawer: Drawer(
        child: Center(
      child: ListView(
        children: [
          const DrawerHeader(
              child: Icon(
                        Icons.person,
                        size: 130,
                        color: Colors.grey,
                )),
          
          const SizedBox(
            height: 20,
          ),
       
          ListTile(
            leading: const Icon(
              Icons.view_agenda,
              size: 30,
              color: Colors.blue,),
            title: const Text(
              '  APS',
              style: TextStyle(fontSize: 25),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, color: Colors.blue,),
            
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) =>   APSCalculator()
              ));
            },
          ),
          ListTile(
            leading: const Icon(Icons.subject, size: 30, color: Colors.blue,),
            title: const Text(
              '  Subjects',
              style: TextStyle(fontSize: 25),
            ),
             trailing: const Icon(Icons.arrow_forward_ios, color: Colors.blue,),

            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) =>  SubjectsView()
              ));
            },
          ),
          ListTile(
            leading: const Icon(Icons.book, size: 30, color: Colors.blue,),
            title: const Text(
              '  Resources',
              style: TextStyle(fontSize: 25),
            ),
          trailing: const Icon(Icons.arrow_forward_ios, color: Colors.blue,),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) =>  Resources()
              ));
            },
          ),
         const SizedBox(height: 145,),
          ListTile(
            title: const Text(
              '  Exit',
              style: TextStyle(fontSize: 25),
            ),
            trailing: const Icon(
              Icons.exit_to_app,
              size: 45,
              color: Colors.red,
            ),
            onTap: () {
               Navigator.pop(context);
            },
          ),
        
    ]  ),
    ),
      
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color.fromARGB(255, 112, 106, 124), // Light Purple
                    Color(0xFF512DA8), // Dark Purple
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                     
                      // IconButton for saving all subjects
                      IconButton(
                        icon: const Icon(
                          Icons.save,
                          color: Colors.white,
                          size: 30,
                        ),
                        onPressed: () async {
                          saveAllSubjectsInUI(context);
                        },
                      ),
                      // IconButton for adding a new subjects
                      IconButton(
                        icon: const Icon(
                          Icons.add,
                          color: Colors.white,
                          size: 30,
                        ),
                        onPressed: () {
                          showDialog(
                            barrierDismissible: false,
                            context: context,
                            builder: (context) {
                              return Dialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Container(
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Color(0xFF9575CD), // Light Purple
                                        Color(0xFF512DA8), // Dark Purple
                                      ],
                                    ),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(20.0),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        const Text(
                                          'Add your Matric Subject',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        // Text field for entering subject description
                                        Container(
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            border: Border.all(
                                              color: Colors.white,
                                            ),
                                          ),
                                          child: TextField(
                                            decoration: const InputDecoration(
                                              hintText:
                                                  'Please enter your subject name',
                                              hintStyle: TextStyle(
                                                  color: Colors.white70),
                                              border: InputBorder.none,
                                              contentPadding:
                                                  EdgeInsets.symmetric(
                                                      horizontal: 10),
                                            ),
                                            cursorColor: Colors.white,
                                            style: const TextStyle(
                                                color: Colors.white),
                                            controller: subjectDesccontroller,
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        // Text field for entering subject reflection
                                        Container(
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            border: Border.all(
                                              color: Colors.white,
                                            ),
                                          ),
                                          child: TextField(
                                            decoration: const InputDecoration(
                                              hintText:
                                                  'Please enter your subject level',
                                              hintStyle: TextStyle(
                                                  color: Colors.white70),
                                              border: InputBorder.none,
                                              contentPadding:
                                                  EdgeInsets.symmetric(
                                                      horizontal: 10),
                                            ),
                                            cursorColor: Colors.white,
                                            style: const TextStyle(
                                                color: Colors.white),
                                            controller: reflectionscontroller,
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        // Buttons for canceling and saving the new subject
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            TextButton(
                                              child: const Text(
                                                'Cancel',
                                                style: TextStyle(
                                                    color: Colors.red),
                                              ),
                                              onPressed: () {
                                                Navigator.pop(context);
                                              },
                                            ),
                                            ElevatedButton(
                                              child: const Text(
                                                'Save',
                                                style: TextStyle(
                                                    color: Colors.white),
                                              ),
                                              onPressed: () async {
                                                createNewSubjectInUI(
                                                  context,
                                                  subjectdesccontroller:
                                                      subjectDesccontroller,
                                                  reflectionscontroller:
                                                      reflectionscontroller,
                                                );
                                              },
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          );
                        },
                      ),
                      // IconButton for logging out the user
                      
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: provider.Selector<UserManagement, BackendlessUser?>(
                    selector: (context, value) => value.currentUser,
                    builder: (context, value, child) {
                      // Display the user's name followed by "Subject List" if logged in,
                      // otherwise display just "Subject List".
                      return value == null
                          ? Text(
                              'Subject List',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.ubuntu(
                                fontSize: 45,
                                fontWeight: FontWeight.w300,
                                color: Colors.white,
                              ),
                            )
                          : Text(
                              '${value.getProperty('name')}\'s Subject List',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.ubuntu(
                                fontSize: 45,
                                fontWeight: FontWeight.w300,
                                color: Colors.white,
                              ),
                            );
                    },
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8.0,
                      vertical: 20,
                    ),
                    child: provider.Consumer<SubjectService>(
                      builder: (context, value, child) {
                        // Display the list of subject using a ListView.builder.
                        return ListView.builder(
                          itemCount: value.subjects.length,
                          itemBuilder: (context, index) {
                            return GestureDetector(
                              onTap: () {
                                showDialog(
                                  barrierDismissible: false,
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      elevation: 4,
                                      title: Text(value.subjects[index].subjectDesc),
                                      content: SingleChildScrollView(
                                        child: ListBody(
                                          children: [
                                            Text(
                                                value.subjects[index].reflections),
                                          ],
                                        ),
                                      ),
                                      actions: [
                                        TextButton(
                                          child: const Text('Close'),
                                          onPressed: () {
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                      ],
                                    );
                                  },
                                );
                              },
                              child: SubjectsCard(
                                subjects : value.subjects[index],
                                deleteAction: () async {
                                  context
                                      .read<SubjectService>()
                                      .deleteSubject(value.subjects[index]);
                                },
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Show a progress indicator if user progress is being shown.
          provider.Selector<UserManagement, Tuple2>(
            selector: (context, value) =>
                Tuple2(value.showUserProgress, value.userProgressText),
            builder: (context, value, child) {
              return value.item1
                  ? AppProgressIndicator(text: '${value.item2}')
                  : Container();
            },
          ),
          // Show a progress indicator if retrieving or saving data.
          provider.Selector<SubjectService, Tuple2>(
            selector: (context, value) =>
                Tuple2(value.busyRetrieving, value.busySaving),
            builder: (context, value, child) {
              return value.item1
                  ? const AppProgressIndicator(
                      text:
                          'please be patient while we busy retrieving data from the database')
                  : value.item2
                      ? const AppProgressIndicator(
                          text:
                              'please be patient while we busy saving data to the database',
                        )
                      : Container();
            },
          ),
        ],
      ),
    );
  }
}
  
