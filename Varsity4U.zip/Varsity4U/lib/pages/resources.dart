import 'package:flutter/material.dart';
import 'package:varsity_4_u/models/course_details.dart';
import 'package:varsity_4_u/services/helper_user.dart';
import 'package:varsity_4_u/widgets/course_card.dart';

class Resources extends StatelessWidget {
  Resources({Key? key}) : super(key: key);

  final List<Course> courses = [
    Course(
      title: 'Data Science/Big Data Analytics:',
      requirements: 'Bachelor\'s degree..',
      jobDescription: 'Data scientist, data analyst, business intelligence analyst, machine learning engineer.',
      imageUrl: 'https://tinyurl.com/576b9ru2',
      institutions: 'CUT, WITS, UJ, CPUT, UP, UFS.',
    ),
    Course(
      title: 'Information Technology',
      requirements: 'Bachelor\'s degree',
      jobDescription: 'IT consultant, software developer, network administrator.',
      imageUrl: 'https://shorturl.at/LSW29',
      institutions: 'UWC, CUT, UCT, WITS',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          actions:  [
            IconButton(
         icon: const Icon(
         Icons.exit_to_app,
         color: Colors.white,
         size: 30,
           ),
         onPressed: () {
         logoutUserInUI(context);
            },
           ),
          ],
          title: const Text('Resources'),
          backgroundColor: Colors.blue,
        ),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    '  Top Trending Courses',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                 
              
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: courses.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CourseDetailPage(course: courses[index]),
                        ),
                      );
                    },
                    child: CourseCard(course: courses[index]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Course {
  final String title;
  final String requirements;
  final String jobDescription;
  final String imageUrl;
  final String institutions;

  Course({
    required this.title,
    required this.requirements,
    required this.jobDescription,
    required this.imageUrl,
    required this.institutions,
  });
}

