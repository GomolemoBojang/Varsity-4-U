import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:varsity_4_u/services/helper_user.dart';


class Result {
  String subject;
  int level;

  Result({required this.subject, required this.level});

  Map<String, dynamic> toMap() {
    return {
      'subject': subject,
      'level': level,
    };
  }

  factory Result.fromMap(Map<String, dynamic> map) {
    return Result(
      subject: map['subject'] as String,
      level: map['level'] as int,
    );
  }
}

class APSCalculator extends StatefulWidget {
  const APSCalculator({key});

  @override
  State<APSCalculator> createState() => _APSCalculatorState();
}

class _APSCalculatorState extends State<APSCalculator> {
  List<Result> results = [];
  TextEditingController subjectController = TextEditingController();
  TextEditingController levelController = TextEditingController();
  int? editingIndex;
  int totalAPS = 0;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    // Load results from SharedPreferences when the app starts
    loadResults();
  }

  @override
  void dispose(){
    saveResults();
    super.dispose();
  }

  void showSnackbar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> saveResults() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> resultsJson = results.map((result) => result.toMap().toString()).toList();
    await prefs.setStringList('results', resultsJson);
  }
Future<void> loadResults() async {
  try {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? resultsJson = prefs.getStringList('results');

    if (resultsJson != null) {
      setState(() {
        results = resultsJson
            .map((result) {
              try {
                return Result.fromMap(json.decode(result));
              } catch (e) {
                
                return null;
              }
            })
            .where((result) => result != null)
            .cast<Result>()
            .toList();

        calculateTotalAPS();
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  } catch (e) {
    setState(() {
      isLoading = false;
    });
    
  }
}


  Future<void> addResult(BuildContext context) async {
    String subject = subjectController.text;
    int? level = int.tryParse(levelController.text);

    if (subject.isNotEmpty && level != null && level > 0) {
      try {
        setState(() {
          if (editingIndex != null) {
            // Edit existing result
            results[editingIndex!] = Result(subject: subject, level: level);
            showSnackbar(context, 'Result edited successfully');
          } else {
            // Add new result
            results.add(Result(subject: subject, level: level));
            showSnackbar(context, 'Result added successfully');
          }

          calculateTotalAPS();
          clearForm();
          editingIndex = null;

          // Save results to SharedPreferences
            saveResults();
        });
      } catch (e) {
        showSnackbar(context, 'Error saving results');
      }
    } else {
      showSnackbar(context, 'Invalid input. Please enter a valid level.');
    }
  }

  void calculateTotalAPS() {
    totalAPS = results.isNotEmpty ? results.fold(0, (sum, result) => sum + result.level) : 0;
  }

  Future<void> editResult(int index) async {
    Result result = results[index];
    subjectController.text = result.subject;
    levelController.text = result.level.toString();

    setState(() {
      editingIndex = index;
    });
  }

  Future<void> deleteResult(int index) async {
    bool confirm = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirmation'),
          content: const Text('Are you sure you want to delete this result?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirm == true) {
      try {
        setState(() {
          results.removeAt(index);
          calculateTotalAPS();
          showSnackbar(context, 'Result deleted successfully');

          // Save results to SharedPreferences after deletion
          saveResults();
        });
      } catch (e) {
        // ignore: use_build_context_synchronously
        showSnackbar(context, 'Error deleting result');
      }
    }
  }

  void clearForm() {
    subjectController.clear();
    levelController.clear();
  }

  Future<void> clearResults() async {
    bool confirm = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirmation'),
          content: const Text('Are you sure you want to clear all results?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Clear'),
            ),
          ],
        );
      },
    );

    if (confirm == true) {
      try {
        setState(() {
          results.clear();
          calculateTotalAPS();
          showSnackbar(context, 'All results cleared');

          // Save results to SharedPreferences after clearing
          saveResults();
        });
      } catch (e) {
        // ignore: use_build_context_synchronously
        showSnackbar(context, 'Error clearing results');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Matric Results'),
          actions: [
             IconButton(
         icon: Icon(
         Icons.exit_to_app,
         color: Colors.white,
         size: 30,
           ),
         onPressed: () {
         logoutUserInUI(context);
            },
           ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SafeArea(
            child: Column(
              children: [
                TextField(
                  controller: subjectController,
                  decoration: const InputDecoration(labelText: 'Subject'),
                ),
                TextField(
                  controller: levelController,
                  decoration: const InputDecoration(labelText: 'Level'),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 10.0),
                ElevatedButton(
                  onPressed: () => addResult(context),
                  child: Text(editingIndex != null ? 'Edit Result' : 'Add Result'),
                ),
                const SizedBox(height: 10.0),
                Text('Total APS: $totalAPS'),
                const SizedBox(height: 10.0),
                Expanded(
                  child: isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : ListView.builder(
                          itemCount: results.length,
                          itemBuilder: (context, index) {
                            return ListTile(
                              title: Text('${results[index].subject} - Level ${results[index].level}'),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.edit),
                                    onPressed: () => editResult(index),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete),
                                    onPressed: () => deleteResult(index),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
                const SizedBox(height: 10.0),
                ElevatedButton(
                  onPressed: () => clearResults(),
                  child: const Text('Clear All Results'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}