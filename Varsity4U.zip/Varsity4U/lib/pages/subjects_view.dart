// ignore_for_file: avoid_print

import 'package:flutter/material.dart';
import 'package:varsity_4_u/services/helper_user.dart';

class SubjectsView extends StatefulWidget {
  const SubjectsView({key});

  @override
  State<SubjectsView> createState() => _SubjectsViewState();
}

class _SubjectsViewState extends State<SubjectsView> {
    TextEditingController subjectsController = TextEditingController();
    List<String> suggestedMajors = [];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Subjects Page'),
        actions: [
           IconButton(
         icon: const Icon(
         Icons.exit_to_app,
         color: Colors.white,
         size: 30,
           ),
         onPressed: () {
         logoutUserInUI(context);
            },
           ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: subjectsController,
              decoration: const InputDecoration(
                labelText: 'Enter subjects (comma-separated)',
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              showSuggestedMajors();
            },
            child: const Text('Get Suggested Majors'),
          ),
          Expanded(
            child: suggestedMajors.isNotEmpty
                ? ListView.builder(
                    itemCount: suggestedMajors.length,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          navigateToMajorDetails(suggestedMajors[index]);
                        },
                        child: Card(
                          margin: const EdgeInsets.all(8),
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Text(
                              suggestedMajors[index],
                              style: const TextStyle(fontSize: 18),
                            ),
                          ),
                        ),
                      );
                    },
                  )
                : const Center(
                    child: Text('No suggested majors.'),
                  ),
          ),
        ],
      ),
    );
}


 
  void showSuggestedMajors() {
    suggestedMajors.clear();

    String subjectsText = subjectsController.text.trim();
    List<String> enteredSubjects = subjectsText.split(',');

    for (int i = 0; i < enteredSubjects.length; i++) {
      String subject = enteredSubjects[i].toLowerCase().trim();
 
      if (subject.contains('computer')) {
        suggestedMajors.add('Computer Science or Information Technology');
    
      }
    }

    suggestedMajors = suggestedMajors.toSet().toList();

    setState(() {}); // Trigger a rebuild to update the UI

    print('Entered Subjects: $enteredSubjects');
    print('Suggested Majors: $suggestedMajors');
  }

  void navigateToMajorDetails(String major) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MajorDetailsPage(major: major),
      ),
    );
  }
}

class MajorDetailsPage extends StatelessWidget {
  final String major;

  const MajorDetailsPage({key, required this.major});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Major Details'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Major: $major',
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              const Text(
                'Bachelor\'s Degree.',
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 20),
              const Text(
                'Employment Opportunities: Computer Scientist, IT Specialist, Application analyst, Applications developer, Cyber security analyst.',
                style: TextStyle(fontSize: 18),
              ),
            
            ],
          ),
        ),
      ),
    );
  }
}
