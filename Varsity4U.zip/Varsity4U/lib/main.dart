import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:varsity_4_u/routes/routes.dart';
import 'package:varsity_4_u/services/subjects_service.dart';
import 'package:varsity_4_u/services/user_service.dart';

// The main entry point of the application
void main() {
  // Run the app
  runApp(const MyApp());
}

// The root widget of the application
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // Provider for UserManagement, which manages user authentication and login state
        ChangeNotifierProvider(
          create: (context) => UserManagement(),
        ),
        
        // Provider for SubjectService, which manages subject-related data and operations
        ChangeNotifierProvider(
          create: (context) => SubjectService(),
        ),
     
      ],
      child: const MaterialApp(
        debugShowCheckedModeBanner: false,
        // The initial route of the application
        initialRoute: RouteManager.welcome,
        // Callback function to generate routes dynamically
        onGenerateRoute: RouteManager.generateRoute,
      ),
    );
  }
}
