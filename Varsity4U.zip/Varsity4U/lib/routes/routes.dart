import 'package:flutter/material.dart';
import 'package:varsity_4_u/pages/loading_page.dart';
import 'package:varsity_4_u/pages/login.dart';
import 'package:varsity_4_u/pages/register.dart';
import 'package:varsity_4_u/pages/subjects_reflection.dart';



class RouteManager {
  // Define route names as constants
  static const String welcome = '/';
  static const String loginPage = 'loginPage';
  static const String registerPage = 'registerPage';
  static const String subjectsReflection = 'subjectsReflection';

  // Generate routes based on the provided settings
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case welcome:
        // Return a MaterialPageRoute for the welcome page
        return MaterialPageRoute(
          builder: (context) => const Welcome(),
        );

      case loginPage:
        // Return a MaterialPageRoute for the login page
        return MaterialPageRoute(
          builder: (context) => const Login(),
        );

      case registerPage:
        // Return a MaterialPageRoute for the register page
        return MaterialPageRoute(
          builder: (context) => const Register(),
        );

      case subjectsReflection:
        // Return a MaterialPageRoute for the subjects reflection page
        return MaterialPageRoute(
          builder: (context) => const SubjectsReflection(),
        );

      default:
        // Throw a FormatException when the route is not found
        throw const FormatException('Route not found! Check routes again!');
    }
  }
}
